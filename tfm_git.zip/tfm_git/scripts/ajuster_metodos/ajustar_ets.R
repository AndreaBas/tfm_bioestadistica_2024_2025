library(forecast)
library(dplyr)
library(readr)
library(stringr)

# importar datos
datos <- readRDS("datos/series_originales.rds")

# crear carpetas de salida si no existen
if (!dir.exists("modelos_guardados")) dir.create("modelos_guardados")
if (!dir.exists("resultados_metricas")) dir.create("resultados_metricas")

# Inicializar tabla resumen
resumen_modelos_ets <- data.frame(
  CCAA = character(),
  Variable = character(),
  Modelo_ETS = character(),
  stringsAsFactors = FALSE
)

# iterar en cada serie
for (serie in datos) {
  ccaa <- serie$ccaa
  variable <- serie$variable
  df <- serie$data
  
  df_train <- df %>% filter(Anyo <= 2016)
  if (nrow(df_train) < 8) next  # datos suficientes?
  
  ts_data <- ts(df_train$valores, start = min(df_train$Anyo), frequency = 1)
  
  modelo_ets <- ets(ts_data)
  
  # guardar modelo
  nombre_archivo <- paste0("modelos_guardados/ets_", 
                           str_replace_all(ccaa, " ", "_"), "_", 
                           str_replace_all(variable, " ", "_"), ".rds")
  saveRDS(modelo_ets, nombre_archivo)
  
  
  modelo_str <- paste0("ETS(", paste(modelo_ets$components, collapse = ","), ")")
  
  resumen_modelos_ets <- rbind(resumen_modelos_ets, data.frame(
    CCAA = ccaa,
    Variable = variable,
    Modelo_ETS = modelo_str
  ))
  
  cat("Modelo ETS ajustado y guardado para:", ccaa, "-", variable, "\n")
}

# exportar tabla resumen
write.csv(resumen_modelos_ets, "resultados_metricas/resumen_modelos_ets.csv", row.names = FALSE)
saveRDS(resumen_modelos_ets, "resultados_metricas/resumen_modelos_ets.rds")

cat("Tabla resumen de modelos ETS guardada con", nrow(resumen_modelos_ets), "modelos.\n")
