# Ajuste modelos por redes neuronales

library(forecast)
library(dplyr)
library(readr)
library(stringr)
library(writexl)

#cargar datos

datos <- readRDS("datos/series_originales.rds")

#crear carpetas de salida si no existe

if (!dir.exists("modelos_guardados")) dir.create("modelos_guardados")
if (!dir.exists("resultados_metricas")) dir.create("resultados_metricas")

# crear dataframe
resumen_modelos_nnetar <- data.frame(
  CCAA = character(),
  Variable = character(),
  Lags_p = numeric(),
  Neuronas_k = numeric(),
  Repeats = numeric(),
  Status = character(),
  Warning = character(),
  Error = character(),
  stringsAsFactors = FALSE
)

# iterar por serie

for (serie in datos) {
  ccaa <- serie$ccaa
  variable <- serie$variable
  df <- serie$data
  
  df_train <- df %>% filter(Anyo <= 2016)
  warning_mensaje <- NA
  error_mensaje <- NA
  
  if (sd(df_train$valores) == 0) {
    warning_mensaje <- "Serie con variabilidad nula"
    cat("Serie plana:", ccaa, "-", variable, "\n")
  }
  
  ts_data <- ts(df_train$valores, start = min(df_train$Anyo), frequency = 1)
  
  modelo_nnetar <- withCallingHandlers({
    tryCatch({
      nnetar(ts_data, repeats = 20)
    }, error = function(e) {
      error_mensaje <<- conditionMessage(e)
      return(NULL)
    })
  }, warning = function(w) {
    warning_mensaje <<- conditionMessage(w)
    invokeRestart("muffleWarning")
  })
  
  if (is.null(modelo_nnetar)) {
    resumen_modelos_nnetar <- rbind(resumen_modelos_nnetar, data.frame(
      CCAA = ccaa,
      Variable = variable,
      Lags_p = NA,
      Neuronas_k = NA,
      Repeats = 20,
      Status = "Error",
      Warning = warning_mensaje,
      Error = error_mensaje
    ))
    cat("Error en", ccaa, "-", variable, ":", error_mensaje, "\n")
    next
  }
  #guardar modelos
  nombre_archivo <- paste0("modelos_guardados/nnetar_", 
                           str_replace_all(ccaa, " ", "_"), "_", 
                           str_replace_all(variable, " ", "_"), ".rds")
  saveRDS(modelo_nnetar, nombre_archivo)
  
  if (!is.null(modelo_nnetar$p) && !is.null(modelo_nnetar$size)) {
    resumen_modelos_nnetar <- rbind(resumen_modelos_nnetar, data.frame(
      CCAA = ccaa,
      Variable = variable,
      Lags_p = modelo_nnetar$p,
      Neuronas_k = modelo_nnetar$size,
      Repeats = 20,
      Status = "OK",
      Warning = warning_mensaje,
      Error = NA
    ))
    cat("Modelo NNETAR guardado para:", ccaa, "-", variable, "\n")
  } else {
    resumen_modelos_nnetar <- rbind(resumen_modelos_nnetar, data.frame(
      CCAA = ccaa,
      Variable = variable,
      Lags_p = NA,
      Neuronas_k = NA,
      Repeats = 20,
      Status = "Incomplete",
      Warning = warning_mensaje,
      Error = NA
    ))
    cat("Modelo NNETAR incompleto:", ccaa, "-", variable, "\n")
  }
}

#exportar resumen
saveRDS(resumen_modelos_nnetar, "resultados_metricas/resumen_modelos_nnetar.rds")
write_xlsx(resumen_modelos_nnetar, "resultados_metricas/resumen_modelos_nnetar.xlsx")

cat("Resumen NNETAR guardado con", nrow(resumen_modelos_nnetar), "series procesadas.\n")
