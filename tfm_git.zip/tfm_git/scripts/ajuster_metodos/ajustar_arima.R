#Ajustar modelos ARIMA

library(forecast)
library(dplyr)
library(readr)
library(stringr)

# cargar datos
datos <- readRDS("datos/series_originales.rds")

# crear carpetas de salida si no existen
if (!dir.exists("modelos_guardados")) dir.create("modelos_guardados")
if (!dir.exists("resultados_metricas")) dir.create("resultados_metricas")

# crear tabla resumen
resumen_modelos_arima <- data.frame(
  CCAA = character(),
  Variable = character(),
  Modelo_ARIMA = character(),
  stringsAsFactors = FALSE
)

# iterar cada serie
for (serie in datos) {
  ccaa <- serie$ccaa
  variable <- serie$variable
  df <- serie$data
  
  df_train <- df %>% filter(Anyo <= 2016)
  if (nrow(df_train) < 8) next  # datos suficientes?
  
  ts_data <- ts(df_train$valores, start = min(df_train$Anyo), frequency = 1)
  
  modelo_arima <- auto.arima(ts_data)
  
  # guardar modelo
  nombre_archivo <- paste0("modelos_guardados/arima_", 
                           str_replace_all(ccaa, " ", "_"), "_", 
                           str_replace_all(variable, " ", "_"), ".rds")
  saveRDS(modelo_arima, nombre_archivo)
  
  # extrar modelo ARIMA seleccionada
  modelo_str <- paste0("ARIMA(", paste(arimaorder(modelo_arima), collapse = ","), ")")
  
  # Añadir a la tabla resumen
  resumen_modelos_arima <- rbind(resumen_modelos_arima, data.frame(
    CCAA = ccaa,
    Variable = variable,
    Modelo_ARIMA = modelo_str
  ))
  
  cat("Modelo ARIMA ajustado y guardado para:", ccaa, "-", variable, "\n")
}

# exportar tabla resumen
write.csv(resumen_modelos_arima, "resultados_metricas/resumen_modelos_arima.csv", row.names = FALSE)
saveRDS(resumen_modelos_arima, "resultados_metricas/resumen_modelos_arima.rds")

cat("Tabla resumen de modelos ARIMA guardada con", nrow(resumen_modelos_arima), "modelos.\n")
