# Ajustar modelos ARIMA bayesianos
library(posterior)
library(bayesforecast)
library(dplyr)
library(stringr)
library(readr)
library(writexl)


# importar datos
datos_completos <- readRDS("datos/series_originales.rds")

# crear carpetas de salida si no existen
if (!dir.exists("modelos_guardados")) dir.create("modelos_guardados")
if (!dir.exists("resultados_metricas")) dir.create("resultados_metricas")

# crear dataframe resumen
resumen_modelos_bayes <- data.frame(
  CCAA = character(),
  Variable = character(),
  ARIMA_orden = character(),
  Iter = integer(),
  Rhat_max = numeric(),
  ESS_bulk_min = numeric(),
  ESS_tail_min = numeric(),
  Status = character(),
  Warning = character(),
  stringsAsFactors = FALSE
)

# iterar las series
for (serie in datos_completos) {
  warning_mensaje <- NULL
  error_mensaje <- NULL
  flag_status <- "OK"
  
  ccaa <- serie$ccaa
  variable <- serie$variable
  df <- serie$data
  
  df_train <- df %>% filter(Anyo <= 2016)
  if (nrow(df_train) < 8) {
    warning_mensaje <- "Serie corta (<8 observaciones)"
    flag_status <- "Short series"
  } else if (sd(df_train$valores) == 0) {
    warning_mensaje <- "Serie sin variabilidad"
    flag_status <- "Constant series"
  }
  
  ts_data <- ts(df_train$valores, start = min(df_train$Anyo), frequency = 1)
  
  modelo_bayes <- withCallingHandlers({
    tryCatch({
      auto.sarima(ts_data,
                  seasonal = FALSE,
                  chains = 4,
                  iter = 5000,
                  warmup = 1000,
                  adapt.delta = 0.995)
    }, error = function(e) {
      error_mensaje <<- conditionMessage(e)
      cat("Error en", ccaa, "-", variable, ":", error_mensaje, "\n")
      return(NULL)
    })
  }, warning = function(w) {
    warning_mensaje <<- paste(warning_mensaje, conditionMessage(w), sep = " | ")
    message("Warning para ", ccaa, " - ", variable, ": ", conditionMessage(w))
    invokeRestart("muffleWarning")
  })
  
  if (is.null(modelo_bayes)) {
    resumen_modelos_bayes <- rbind(resumen_modelos_bayes, data.frame(
      CCAA = ccaa,
      Variable = variable,
      ARIMA_orden = NA,
      Iter = 5000,
      Rhat_max = NA,
      ESS_bulk_min = NA,
      ESS_tail_min = NA,
      Status = paste("Error", flag_status, sep = " | "),
      Warning = ifelse(is.null(error_mensaje), warning_mensaje, error_mensaje)
    ))
    next
  }
  
  orden <- modelo_bayes$model
  orden_str <- paste0("ARIMA(", orden$p, ",", orden$d, ",", orden$q, ")")
  
  resumen_mcmc <- tryCatch({
    posterior::summarise_draws(modelo_bayes$stanfit)
  }, error = function(e) NULL)
  
  rhat_max <- if (!is.null(resumen_mcmc)) max(resumen_mcmc$rhat, na.rm = TRUE) else NA
  ess_bulk_min <- if (!is.null(resumen_mcmc)) min(resumen_mcmc$ess_bulk, na.rm = TRUE) else NA
  ess_tail_min <- if (!is.null(resumen_mcmc)) min(resumen_mcmc$ess_tail, na.rm = TRUE) else NA
  
  nombre_archivo <- paste0("modelos_guardados/bayes_", 
                           str_replace_all(ccaa, " ", "_"), "_", 
                           str_replace_all(variable, " ", "_"), ".rds")
  saveRDS(modelo_bayes, nombre_archivo)
  
  resumen_modelos_bayes <- rbind(resumen_modelos_bayes, data.frame(
    CCAA = ccaa,
    Variable = variable,
    ARIMA_orden = orden_str,
    Iter = 5000,
    Rhat_max = rhat_max,
    ESS_bulk_min = ess_bulk_min,
    ESS_tail_min = ess_tail_min,
    Status = flag_status,
    Warning = ifelse(is.null(warning_mensaje), NA, warning_mensaje)
  ))
  
  print("Modelo bayesiano ajustado para:", ccaa, "-", variable, "\n")
}

# Guardar resumen
write_xlsx(resumen_modelos_bayes, "resultados_metricas/resumen_modelos_bayes_full.xlsx")
saveRDS(resumen_modelos_bayes, "resultados_metricas/resumen_modelos_bayes_full.rds")
