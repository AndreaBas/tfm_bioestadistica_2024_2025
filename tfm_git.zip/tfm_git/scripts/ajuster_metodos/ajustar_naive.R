#Ajustar modelo NAIVE

library(forecast)
library(dplyr)
library(stringr)

# Cargar datos
series <- readRDS("datos/series_originales.rds")

# crear carpeta de salida si no existe
if (!dir.exists("modelos_guardados")) dir.create("modelos_guardados")

# iterar por serie
for (serie in series) {
  ccaa <- serie$ccaa
  variable <- serie$variable
  df <- serie$data
  
  df_train <- df %>% filter(Anyo <= 2016)
  
  if (nrow(df_train) < 2) next
  
  ts_data <- ts(df_train$valores, start = min(df_train$Anyo), frequency = 1)
  
  modelo_naive <- naive(ts_data)
  
  nombre_archivo <- paste0("modelos_guardados/naive_", 
                           str_replace_all(ccaa, " ", "_"), "_", 
                           str_replace_all(variable, " ", "_"), ".rds")
  #guardar modelo
  saveRDS(modelo_naive, nombre_archivo)
  
  cat("Modelo naive guardado para:", ccaa, "-", variable, "\n")
}

