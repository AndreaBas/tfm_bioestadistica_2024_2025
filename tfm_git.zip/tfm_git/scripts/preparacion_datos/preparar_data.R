library(dplyr)
library(tidyr)
library(readxl)
library(lubridate)
library(writexl)

crear_lista_series <- function(path_excel = "datos/Datos.xlsx",
                               hoja = 2,
                               archivo_salida = "datos/series_originales.rds")
  {
  
  datos <- read_excel(path_excel, sheet = hoja)
  
  # Transformar a formato largo
  datos_long <- pivot_longer(datos, 
                             cols = Total:Melilla,
                             names_to = "CCAA",
                             values_to = "valores")
  
  ccaas <- unique(datos_long$CCAA)
  variables <- unique(datos_long$Variable_nombre)
  
  lista_series <- list()
  i <- 1
  
  for (comunidad_elegida in ccaas) {
    for (variable_elegida in variables) {
      
      df_filtrado <- datos_long %>%
        filter(CCAA == comunidad_elegida, Variable_nombre == variable_elegida) %>%
        arrange(Anyo) %>%
        select(Anyo, valores)
      
      if (nrow(df_filtrado) < 8) next
      
      lista_series[[i]] <- list(
        ccaa = comunidad_elegida,
        variable = variable_elegida,
        data = df_filtrado
      )
      
      i <- i + 1
    }
  }
  
  saveRDS(lista_series, archivo_salida)
  message("Lista de series creada en: ", archivo_salida)
}



# ejecutar

crear_lista_series()