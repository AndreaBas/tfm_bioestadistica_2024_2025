library(dplyr)
library(tidyr)
library(readxl)
library(stringr)

# Leer referencia de variables
mapeo <- read_excel("datos/tabla_mapeo_variables.xlsx") %>%
  rename(Variable = Variable_nombre)


# cargar series originales y predichas
datos_reales <- readRDS("datos/series_originales.rds")
datos_predichos <-readRDS("series_prediccion/nuevas_series_prediccion_corregidas_v2.rds")


# convertir lista de series a tabla
series_a_tabla <- function(lista_series) {
  bind_rows(lapply(lista_series, function(s) {
    data.frame(
      CCAA = s$ccaa,
      Variable = s$variable,
      Anyo = s$data$Anyo,
      valores = s$data$valores
    )
  }))
}

# convertir series originales y predichas a tablas
datos_reales <- series_a_tabla(series_originales)
datos_predichos <- series_a_tabla(datos_predichos)

# Unir nombres y sentido delas variables
datos_reales <- left_join(datos_reales, mapeo, by = "Variable")
datos_predichos <- left_join(datos_predichos, mapeo, by = "Variable")

# Calcular referencia (España 2008)
referencia <- datos_reales %>%
  filter(CCAA == "Total", Anyo == 2008) %>%
  select(Variable, valores_ref = valores)

# Calcular delta max y min por variable
delta <- datos_reales %>%
  group_by(Variable) %>%
  summarise(
    maximo = max(valores, na.rm = TRUE),
    minimo = min(valores, na.rm = TRUE),
    delta = (maximo - minimo) / 2
  )

# Combinar con referencia
escala <- left_join(referencia, delta, by = "Variable") %>%
  mutate(
    minimo = valores_ref - delta,
    maximo = valores_ref + delta
  ) %>%
  select(Variable, minimo, maximo)

# Función para reescalar y calcular IMCV
calcular_imcv <- function(df) {
  df %>%
    left_join(escala, by = "Variable") %>%
    mutate(valor_reescalado = ifelse(
      Variable_sentido == 1,
      85 + 30 * (valores - minimo) / (maximo - minimo),
      115 - 30 * (valores - minimo) / (maximo - minimo)
    )) %>%
    group_by(Anyo, Dimension, CCAA) %>%
    summarise(
      media = mean(valor_reescalado, na.rm = TRUE),
      varianza = var(valor_reescalado, na.rm = TRUE),
      AMPI = media - varianza / media,
      .groups = "drop"
    ) %>%
    group_by(Anyo, CCAA) %>% 
    summarise(IMCV = mean(AMPI, na.rm = TRUE), .groups = "drop")
}

# calculo por dimensiones

calcular_imcv_dimensiones <- function(df) {
  df %>%
    left_join(escala, by = "Variable") %>%
    mutate(valor_reescalado = ifelse(
      Variable_sentido == 1,
      85 + 30 * (valores - minimo) / (maximo - minimo),
      115 - 30 * (valores - minimo) / (maximo - minimo)
    )) %>%
    group_by(Anyo, Dimension, CCAA) %>%
    summarise(
      media = mean(valor_reescalado, na.rm = TRUE),
      varianza = var(valor_reescalado, na.rm = TRUE),
      AMPI = media - varianza / media,
      .groups = "drop"
    ) %>%
    rename(IMCV = AMPI)
}




# Calcular IMCV
IMCV_reales <- calcular_imcv(datos_reales)
IMCV_predichos <- calcular_imcv(datos_predichos)

IMCV_reales_dim <- calcular_imcv_dimensiones(datos_reales)
IMCV_predichos_dim <- calcular_imcv_dimensiones(datos_predichos)


# calculo disgregado por dimensiones
IMCV_reales_dim_nacional <- IMCV_reales_dim %>%
  group_by(Anyo, Dimension) %>%
  summarise(IMCV = mean(IMCV, na.rm = TRUE), .groups = "drop")

IMCV_predichos_dim_nacional <- IMCV_predichos_dim %>%
  group_by(Anyo, Dimension) %>%
  summarise(IMCV = mean(IMCV, na.rm = TRUE), .groups = "drop")


# Guardar

# Excel imcv

writexl::write_xlsx(list(
  IMCV_reales = IMCV_reales,
  IMCV_predichos = IMCV_predichos
), "datos/imcv_resultados.xlsx")


writexl::write_xlsx(list(
  IMCV_reales_dim = IMCV_reales_dim,
  IMCV_predichos_dim = IMCV_predichos_dim
), "datos/imcv_resultados_ccaa_dim.xlsx")


writexl::write_xlsx(list(
  IMCV_reales_dim_nacional = IMCV_reales_dim_nacional,
  IMCV_predichos_dim_nacional = IMCV_predichos_dim_nacional
), "datos/imcv_resultados_dim.xlsx")


# Excel datos

writexl::write_xlsx(list(
  datos_reales = datos_reales,
  datos_predichos = datos_predichos
), "datos/datos_completos_reales_y_predichos.xlsx")

# RDS
saveRDS(datos_reales, "datos/datos_reales_completos.rds")
saveRDS(datos_predichos, "datos/datos_predichos_completos.rds")
saveRDS(IMCV_reales, "datos/IMCV_reales_completos.rds")
saveRDS(IMCV_predichos, "datos/IMCV_predichos_completos.rds")


