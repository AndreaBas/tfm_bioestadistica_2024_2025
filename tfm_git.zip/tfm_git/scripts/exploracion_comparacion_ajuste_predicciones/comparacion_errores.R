library(readxl)
library(dplyr)
library(writexl)
library(stringr)

# datos
resumen_comparacion <- read_xlsx("resultados_comparacion/comparacion_modelos.xlsx", sheet = "Comparacion completa")
mejores_modelos <- read_xlsx("resultados_comparacion/comparacion_modelos.xlsx", sheet = "Mejores modelos")

# tratar las variables numericas como numericas
resumen_comparacion <- resumen_comparacion %>%
  mutate(RMSE = as.numeric(RMSE), MAPE = as.numeric(MAPE))

# Error total por CCAA (todos los modelos)
error_ccaa_todos <- resumen_comparacion %>%
  group_by(CCAA) %>%
  summarise(
    Total_RMSE = sum(RMSE, na.rm = TRUE),
    Media_RMSE = mean(RMSE, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(Total_RMSE))

# Error total por Variable (todos los modelos)
error_variable_todos <- resumen_comparacion %>%
  group_by(Variable) %>%
  summarise(
    Total_RMSE = sum(RMSE, na.rm = TRUE),
    Media_RMSE = mean(RMSE, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(Total_RMSE))


# Error por CCAA (solo modelos ganadores)
error_ccaa_mejores <- mejores_modelos %>%
  group_by(CCAA) %>%
  summarise(
    Total_RMSE = sum(RMSE, na.rm = TRUE),
    Media_RMSE = mean(RMSE, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(Total_RMSE))

# Error por Variable (solo modelos ganadores)
error_variable_mejores <- mejores_modelos %>%
  group_by(Variable) %>%
  summarise(
    Total_RMSE = sum(RMSE, na.rm = TRUE),
    Media_RMSE = mean(RMSE, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(Total_RMSE))

# Agrupamos por dimensiones

# Función para extraer prefijo de variable (dimension)
extraer_indice <- function(var) {
  str_extract(var, "^V\\.\\d+")
}

# Errores por dimension (todos los modelos)
error_indice_todos <- resumen_comparacion %>%
  mutate(Indice = extraer_indice(Variable)) %>%
  group_by(Indice) %>%
  summarise(
    Total_RMSE = sum(RMSE, na.rm = TRUE),
    Media_RMSE = mean(RMSE, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(Total_RMSE))

# Errores por dimension (solo modelos ganadores)
error_indice_mejores <- mejores_modelos %>%
  mutate(Indice = extraer_indice(Variable)) %>%
  group_by(Indice) %>%
  summarise(
    Total_RMSE = sum(RMSE, na.rm = TRUE),
    Media_RMSE = mean(RMSE, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(Total_RMSE))


# Pivot: RMSE por modelo (una tabla)
pivot_rmse <- resumen_comparacion %>%
  select(CCAA, Variable, Modelo, RMSE) %>%
  pivot_wider(
    id_cols = c(CCAA, Variable),
    names_from = Modelo,
    values_from = RMSE
  ) %>%
  arrange(CCAA, Variable)

write_xlsx(list(
  "Error CCAA - Todos" = error_ccaa_todos,
  "Error Variable - Todos" = error_variable_todos,
  "Error Dimension - Todos" = error_indice_todos,
  "Error CCAA - Mejores" = error_ccaa_mejores,
  "Error Variable - Mejores" = error_variable_mejores,
  "Error Dimension - Mejores" = error_indice_mejores,
  "Pivot detallado RMSE" = pivot_rmse
), "resultados_comparacion/RMSE_errores_por_ccaa_variable.xlsx")

cat("Todos los errores agregados han sido guardados en 'RMSE_errores_por_ccaa_variable.xlsx'")




mape_ccaa_todos <- resumen_comparacion %>%
  group_by(CCAA) %>%
  summarise(Total_MAPE = sum(MAPE, na.rm = TRUE),
            Media_MAPE = mean(MAPE, na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(Total_MAPE))

mape_variable_todos <- resumen_comparacion %>%
  group_by(Variable) %>%
  summarise(Total_MAPE = sum(MAPE, na.rm = TRUE),
            Media_MAPE = mean(MAPE, na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(Total_MAPE))

mape_ccaa_mejores <- mejores_modelos %>%
  group_by(CCAA) %>%
  summarise(Total_MAPE = sum(MAPE, na.rm = TRUE),
            Media_MAPE = mean(MAPE, na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(Total_MAPE))

mape_variable_mejores <- mejores_modelos %>%
  group_by(Variable) %>%
  summarise(Total_MAPE = sum(MAPE, na.rm = TRUE),
            Media_MAPE = mean(MAPE, na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(Total_MAPE))

mape_indice_todos <- resumen_comparacion %>%
  mutate(Indice = extraer_indice(Variable)) %>%
  group_by(Indice) %>%
  summarise(Total_MAPE = sum(MAPE, na.rm = TRUE),
            Media_MAPE = mean(MAPE, na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(Total_MAPE))

mape_indice_mejores <- mejores_modelos %>%
  mutate(Indice = extraer_indice(Variable)) %>%
  group_by(Indice) %>%
  summarise(Total_MAPE = sum(MAPE, na.rm = TRUE),
            Media_MAPE = mean(MAPE, na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(Total_MAPE))


# Pivot: MAPE por modelo (otra tabla)
pivot_mape <- resumen_comparacion %>%
  select(CCAA, Variable, Modelo, MAPE) %>%
  pivot_wider(
    id_cols = c(CCAA, Variable),
    names_from = Modelo,
    values_from = MAPE
  ) %>%
  arrange(CCAA, Variable)


write_xlsx(list(
  "Error CCAA - Todos" = mape_ccaa_todos,
  "Error Variable - Todos" = mape_variable_todos,
  "Error Dimension - Todos" = mape_indice_todos,
  "Error CCAA - Mejores" = mape_ccaa_mejores,
  "Error Variable - Mejores" = mape_variable_mejores,
  "Error Dimension - Mejores" = mape_indice_mejores,
  "Pivot detallado MAPE" = pivot_mape
), "resultados_comparacion/MAPE_errores_por_ccaa_variable.xlsx")

