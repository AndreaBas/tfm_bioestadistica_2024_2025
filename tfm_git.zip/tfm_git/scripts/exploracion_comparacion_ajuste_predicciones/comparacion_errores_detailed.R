library(readxl)
library(dplyr)
library(writexl)
library(stringr)

# datos
resumen_comparacion <- read_xlsx("resultados_comparacion/comparacion_modelos.xlsx", sheet = "Comparacion completa")
mejores_modelos <- read_xlsx("resultados_comparacion/comparacion_modelos.xlsx", sheet = "Mejores modelos")

# tratar las variables numericas como numericas
resumen_comparacion <- resumen_comparacion %>%
  mutate(RMSE = as.numeric(RMSE), MAPE = as.numeric(MAPE))

# ---- ERRORES TOTALES (sin desagregar por modelo) ----
error_ccaa_todos <- resumen_comparacion %>%
  group_by(CCAA) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE),
            Media_RMSE = mean(RMSE, na.rm = TRUE),
            .groups = "drop") %>%
  arrange(desc(Total_RMSE))

error_variable_todos <- resumen_comparacion %>%
  group_by(Variable) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE),
            Media_RMSE = mean(RMSE, na.rm = TRUE),
            .groups = "drop") %>%
  arrange(desc(Total_RMSE))

# ---- ERRORES SOLO PARA LOS MEJORES MODELOS ----
error_ccaa_mejores <- mejores_modelos %>%
  group_by(CCAA) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE),
            Media_RMSE = mean(RMSE, na.rm = TRUE),
            .groups = "drop") %>%
  arrange(desc(Total_RMSE))

error_variable_mejores <- mejores_modelos %>%
  group_by(Variable) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE),
            Media_RMSE = mean(RMSE, na.rm = TRUE),
            .groups = "drop") %>%
  arrange(desc(Total_RMSE))

# ---- POR DIMENSIÓN ----
extraer_indice <- function(var) {
  str_extract(var, "^V\\.\\d+")
}

error_indice_todos <- resumen_comparacion %>%
  mutate(Indice = extraer_indice(Variable)) %>%
  group_by(Indice) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE),
            Media_RMSE = mean(RMSE, na.rm = TRUE),
            .groups = "drop") %>%
  arrange(desc(Total_RMSE))

error_indice_mejores <- mejores_modelos %>%
  mutate(Indice = extraer_indice(Variable)) %>%
  group_by(Indice) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE),
            Media_RMSE = mean(RMSE, na.rm = TRUE),
            .groups = "drop") %>%
  arrange(desc(Total_RMSE))

# ---- NUEVO: AGREGAR POR MODELO ----
error_ccaa_modelo <- resumen_comparacion %>%
  group_by(CCAA, Modelo) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE),
            Media_RMSE = mean(RMSE, na.rm = TRUE),
            .groups = "drop") %>%
  arrange(CCAA, desc(Total_RMSE))

error_variable_modelo <- resumen_comparacion %>%
  group_by(Variable, Modelo) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE),
            Media_RMSE = mean(RMSE, na.rm = TRUE),
            .groups = "drop") %>%
  arrange(Variable, desc(Total_RMSE))

error_indice_modelo <- resumen_comparacion %>%
  mutate(Indice = extraer_indice(Variable)) %>%
  group_by(Indice, Modelo) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE),
            Media_RMSE = mean(RMSE, na.rm = TRUE),
            .groups = "drop") %>%
  arrange(Indice, desc(Total_RMSE))

library(tidyr)  # para pivot_wider

# Pivot RMSE Total por CCAA
error_ccaa_total_pivot <- resumen_comparacion %>%
  group_by(CCAA, Modelo) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = Modelo, values_from = Total_RMSE)

# Pivot RMSE Medio por CCAA
error_ccaa_media_pivot <- resumen_comparacion %>%
  group_by(CCAA, Modelo) %>%
  summarise(Media_RMSE = mean(RMSE, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = Modelo, values_from = Media_RMSE)

# Pivot RMSE Total por Variable
error_variable_total_pivot <- resumen_comparacion %>%
  group_by(Variable, Modelo) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = Modelo, values_from = Total_RMSE)

# Pivot RMSE Medio por Variable
error_variable_media_pivot <- resumen_comparacion %>%
  group_by(Variable, Modelo) %>%
  summarise(Media_RMSE = mean(RMSE, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = Modelo, values_from = Media_RMSE)

# Pivot RMSE Total por Dimension
error_indice_total_pivot <- resumen_comparacion %>%
  mutate(Indice = extraer_indice(Variable)) %>%
  group_by(Indice, Modelo) %>%
  summarise(Total_RMSE = sum(RMSE, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = Modelo, values_from = Total_RMSE)

# Pivot RMSE Medio por Dimension
error_indice_media_pivot <- resumen_comparacion %>%
  mutate(Indice = extraer_indice(Variable)) %>%
  group_by(Indice, Modelo) %>%
  summarise(Media_RMSE = mean(RMSE, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = Modelo, values_from = Media_RMSE)



write_xlsx(list(
  "Error CCAA - Todos" = error_ccaa_todos,
  "Error Variable - Todos" = error_variable_todos,
  "Error Dimension - Todos" = error_indice_todos,
  "Error CCAA - Mejores" = error_ccaa_mejores,
  "Error Variable - Mejores" = error_variable_mejores,
  "Error Dimension - Mejores" = error_indice_mejores,
  "Error CCAA - Por Modelo" = error_ccaa_modelo,
  "Error Variable - Por Modelo" = error_variable_modelo,
  "Error Dimension - Por Modelo" = error_indice_modelo,
  "Pivot CCAA - Total RMSE" = error_ccaa_total_pivot,
  "Pivot CCAA - Media RMSE" = error_ccaa_media_pivot,
  "Pivot Variable - Total RMSE" = error_variable_total_pivot,
  "Pivot Variable - Media RMSE" = error_variable_media_pivot,
  "Pivot Dimension - Total RMSE" = error_indice_total_pivot,
  "Pivot Dimension - Media RMSE" = error_indice_media_pivot
), "resultados_comparacion/RMSE_errores_por_ccaa_variable_modelo_pivot.xlsx")


cat("Todos los errores agregados han sido guardados en 'errores_por_ccaa_variable_modelo_pivot.xlsx'\n")
