library(readxl)
library(dplyr)
library(writexl)
library(stringr)
library(tidyr)

# Cargar datos
resumen_comparacion <- read_xlsx("resultados_comparacion/comparacion_modelos.xlsx", sheet = "Comparacion completa")
resumen_comparacion <- resumen_comparacion %>%
  mutate(RMSE = as.numeric(RMSE), MAPE = as.numeric(MAPE))

# detectar variables planas hasta 2019

series <- readRDS("datos/series_originales.rds")

tabla_series <- lapply(series, function(s) {
  data.frame(
    CCAA = s$ccaa,
    Variable = s$variable,
    Anyo = s$data$Anyo,
    valores = s$data$valores
  )
}) %>% bind_rows()

tabla_filtrada <- tabla_series %>% 
  filter(Anyo <= 2019)

variabilidad <- tabla_filtrada %>%
  group_by(Variable, CCAA) %>%
  summarise(varianza = var(valores, na.rm = TRUE), .groups = "drop") %>%
  mutate(es_plana = is.na(varianza) | varianza == 0)

variables_planas_en_todas <- variabilidad %>%
  group_by(Variable) %>%
  summarise(todas_planas = all(es_plana), .groups = "drop") %>%
  filter(todas_planas == TRUE)

variables_plana <- variables_planas_en_todas$Variable

# Tabla 1: RMSE Medio por Variable (ancho)
rmse_medio_variable_modelo <- resumen_comparacion %>%
  group_by(Variable, Modelo) %>%
  summarise(Media_RMSE = mean(RMSE, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = Modelo, values_from = Media_RMSE)

# Tabla 2: Frecuencia de modelos ganadores (solo no planas)
prioridad_modelos <- c("NAIVE" = 1, "ETS" = 2, "ARIMA" = 3, "NNETAR" = 4, "BAYES" = 5)

mejores_modelos_no_planas <- resumen_comparacion %>%
  filter(!(Variable %in% variables_plana)) %>%
  group_by(Variable, Modelo) %>%
  summarise(Media_RMSE = mean(RMSE, na.rm = TRUE), .groups = "drop") %>%
  mutate(Prioridad = prioridad_modelos[Modelo]) %>%
  group_by(Variable) %>%
  arrange(Media_RMSE, Prioridad) %>%
  slice(1) %>%
  ungroup()

conteo_modelos <- mejores_modelos_no_planas %>%
  count(Modelo, name = "Frecuencia") %>%
  arrange(desc(Frecuencia))

# Tabla 3: Índice variable-modelo (todas las variables)
todas_las_variables <- unique(resumen_comparacion$Variable)

indice_variable_modelo <- tibble(
  Variable = todas_las_variables,
  Modelo_asignado = ifelse(Variable %in% variables_plana, "NAIVE",
                           mejores_modelos_no_planas$Modelo[match(todas_las_variables, mejores_modelos_no_planas$Variable)])
)

# Guardar Excel final
write_xlsx(list(
  "RMSE Medio por Variable (wide)" = rmse_medio_variable_modelo,
  "Frecuencia Modelos Ganadores" = conteo_modelos,
  "Indice Variable-Modelo" = indice_variable_modelo,
  "Variables Planas hasta 2019" = variables_planas_en_todas
), "resultados_comparacion/analisis_modelos_variables_actualizado.xlsx")

cat("✅ Tablas actualizadas y guardadas en 'analisis_modelos_variables_actualizado.xlsx'\n")

