# Comparar modelos de diferentes métodos

library(forecast)
library(readr)
library(dplyr)
library(stringr)
library(tibble)
library(writexl)

# Cargar datos
series <- readRDS("datos/series_originales.rds")
if (!dir.exists("resultados_comparacion")) dir.create("resultados_comparacion")

# métricas
calcular_metricas <- function(pred, reales) {
  rmse <- sqrt(mean((reales - pred)^2, na.rm = TRUE)) # criterio para elegir RMSE, exiten ceros tanto en pred como en el valor real
  mape <- mean(abs((reales - pred) / (reales + pred)), na.rm = TRUE) * 200 # denominador reales + pred *200 para evitar los Inf
  return(c(RMSE = rmse, MAPE = mape))
}

# tabla resumen
resumen_comparacion <- tibble(CCAA = character(),
                              Variable = character(),
                              Modelo = character(),
                              RMSE = numeric(),
                              MAPE = numeric())

# iterar por series
for (i in seq_along(series)) {
  serie <- series[[i]]
  ccaa <- serie$ccaa
  variable <- serie$variable
  df <- serie$data
  df_test <- df %>% filter(Anyo %in% 2017:2019)
  if (nrow(df_test) < 3) next
  
  reales <- df_test$valores
  
  modelos <- list(
    ARIMA = paste0("modelos_guardados/arima_", str_replace_all(ccaa, " ", "_"), "_", str_replace_all(variable, " ", "_"), ".rds"),
    NNETAR = paste0("modelos_guardados/nnetar_", str_replace_all(ccaa, " ", "_"), "_", str_replace_all(variable, " ", "_"), ".rds"),
    BAYES = paste0("modelos_guardados/bayes_", str_replace_all(ccaa, " ", "_"), "_", str_replace_all(variable, " ", "_"), ".rds"),
    NAIVE = paste0("modelos_guardados/naive_", str_replace_all(ccaa, " ", "_"), "_", str_replace_all(variable, " ", "_"), ".rds"),
    ETS = paste0("modelos_guardados/ets_", str_replace_all(ccaa, " ", "_"), "_", str_replace_all(variable, " ", "_"), ".rds")
  )
  
  for (modelo_tipo in names(modelos)) {
    archivo <- modelos[[modelo_tipo]]
    if (!file.exists(archivo)) next
    
    modelo <- tryCatch(readRDS(archivo), error = function(e) NULL)
    if (is.null(modelo)) next
    
    pred <- tryCatch({
      if (modelo_tipo == "NAIVE") {
        ultimo_valor <- df %>% filter(Anyo < 2017) %>% tail(1) %>% pull(valores)
        rep(ultimo_valor, 3)
      } else {
        as.numeric(forecast(modelo, h = 3)$mean)
      }
    }, error = function(e) rep(NA, 3))
    
    metricas <- calcular_metricas(pred, reales)
    
    resumen_comparacion <- add_row(resumen_comparacion,
                                   CCAA = ccaa,
                                   Variable = variable,
                                   Modelo = modelo_tipo,
                                   RMSE = metricas["RMSE"],
                                   MAPE = metricas["MAPE"])
  }
  
  cat(sprintf("[%d/%d] Comparado: %s - %s\n", i, length(series), ccaa, variable))
}

# Seleccionar mejores modelos
mejores_modelos <- resumen_comparacion %>%
  group_by(CCAA, Variable) %>%
  mutate(RMSE_min = min(RMSE, na.rm = TRUE)) %>%
  filter(abs(RMSE - RMSE_min) < 1e-6) %>%
  arrange(desc(Modelo == "NAIVE")) %>% #priorizar naive, modelo mas sencillo
  slice(1) %>%
  ungroup() %>%
  select(-RMSE_min)

# Conteo de modelos ganadores
conteo_modelos <- mejores_modelos %>%
  count(Modelo, name = "Frecuencia") %>%
  arrange(desc(Frecuencia))

# Guardar resultados
write_xlsx(list(
  "Comparacion completa" = resumen_comparacion,
  "Mejores modelos" = mejores_modelos,
  "Frecuencia ganadores" = conteo_modelos
), "resultados_comparacion/comparacion_modelos.xlsx")

cat("Comparación finalizada y guardada en 'resultados_comparacion/comparacion_modelos.xlsx'\n")

