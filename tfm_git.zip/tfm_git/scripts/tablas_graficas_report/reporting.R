library(dplyr)
library(ggplot2)
library(writexl)
library(viridis)
library(showtext)
library(sysfonts)
library(readxl)
library(tidyr)
library(purrr)
library(patchwork)

# Crear carpeta 
dir.create("resultados_report", showWarnings = FALSE)


ccaa_nombres <- read_excel("datos/codificacion_variables.xlsx", sheet = 2)  
dimensiones_nombres <- read_excel("datos/codificacion_variables.xlsx", sheet = 3) %>%
  select(Dimension, dimension_limpia) %>%
  distinct()
IMCV_reales <- IMCV_reales %>%
  left_join(ccaa_nombres, by = c("CCAA" = "ccaa")) %>%
  mutate(CCAA = nombre_ccaa) %>%
  select(-nombre_ccaa)

IMCV_predichos <- IMCV_predichos %>%
  left_join(ccaa_nombres, by = c("CCAA" = "ccaa")) %>%
  mutate(CCAA = nombre_ccaa) %>%
  select(-nombre_ccaa)



# Obtener todas las CCAA (incluyendo "Total")
ccaas <- IMCV_reales %>%
  distinct(CCAA) %>%
  pull()

# Generar lista de tablas
tablas_por_ccaa <- map(ccaas, function(ccaa_actual) {
  real <- IMCV_reales %>% filter(CCAA == ccaa_actual)
  pred <- IMCV_predichos %>% filter(CCAA == ccaa_actual)
  
  tabla <- real %>%
    rename(IMCV_real = IMCV) %>%
    left_join(pred %>% rename(IMCV_predicho = IMCV),
              by = c("Anyo", "CCAA")) %>%
    mutate(Impacto = IMCV_real - IMCV_predicho)
  
  return(tabla)
})

# Asignar nombres a la lista
names(tablas_por_ccaa) <- ccaas

# Guardar - region por hoja
write_xlsx(tablas_por_ccaa, path = "IMCV_por_CCAA_report.xlsx")


### NIVEL NACIONAL ###

# Filtrar datos nacionales (Total)
IMCV_total_real <- IMCV_reales %>% filter(CCAA == "Total")
IMCV_total_pred <- IMCV_predichos %>% filter(CCAA == "Total")

# Unir ambas series
tabla_total <- IMCV_total_real %>%
  rename(IMCV_real = IMCV) %>%
  left_join(IMCV_total_pred %>% rename(IMCV_predicho = IMCV),
            by = c("Anyo", "CCAA")) %>%
  mutate(Impacto = IMCV_real - IMCV_predicho)


# Guardar
write_xlsx(tabla_total, "resultados_report/IMCV_Espana_total_2020_2023_v2.xlsx")

# Crear gráfico de líneas real vs predicho

grafico <- ggplot(tabla_total, aes(x = Anyo)) +
  geom_line(aes(y = IMCV_predicho, color = "Predicho"), size = 1.1) +
  geom_line(aes(y = IMCV_real, color = "Real"), size = 1.1) +
  scale_color_manual(values = c("Real" = "black", "Predicho" = "red")) +
  scale_x_continuous(breaks = seq(min(tabla_total$Anyo), max(tabla_total$Anyo), by = 2)) +
  labs(
    title = "España",
    subtitle = "Valores reales vs. predichos (sin pandemia)",
    x = "Años", 
    y = "IMCV",
    color = "Serie"
  ) +
  theme_gray(base_size = 15, base_family = "Times New Roman")


# Mostrar gráfico
print(grafico)

# Guardar gráfico como imagen
ggsave("resultados_report/IMCV_Espana_comparacion_v2.png", plot = grafico, width = 9, height = 6)







# Comunidades más afectadas
ccaa_grupo1 <- c("Canarias", "Comunitat Valenciana")
ccaa_grupo2 <- c("Madrid", "Catalunya")







#### IMPACTO POR CCAA ###


# Unir por CCAA y Anyo
impacto_ccaa <- IMCV_reales %>%
  inner_join(IMCV_predichos, by = c("Anyo", "CCAA"), suffix = c("_real", "_pred")) %>%
  mutate(impacto = IMCV_real - IMCV_pred)

print(impacto_ccaa)

# Guardar tabla
writexl::write_xlsx(impacto_ccaa, "resultados_report/impacto_imcv_ccaa.xlsx")
saveRDS(impacto_ccaa, "resultados_report/impacto_imcv_ccaa.rds")


# Reorganizar como tabla ancha para el informe
impacto_tabla <- impacto_ccaa %>%
  filter(Anyo >= 2020) %>%
  select(CCAA, Anyo, impacto) %>%
  pivot_wider(names_from = Anyo, values_from = impacto)

print(impacto_tabla)

# Guardar tabla
writexl::write_xlsx(impacto_tabla, "resultados_report/impacto_tabla_ancha_v2.xlsx")


# Reemplazar "Total" por "España"
impacto_2020 <- impacto_ccaa %>%
  mutate(CCAA = ifelse(CCAA == "Total", "España", CCAA)) %>%
  filter(Anyo == 2020)

# Ordenar las CCAA por impacto
impacto_2020 <- impacto_2020 %>%
  mutate(CCAA = factor(CCAA, levels = impacto_2020 %>% arrange(impacto) %>% pull(CCAA)))


# Crear gráfico
barras_2020 <- ggplot(impacto_2020, aes(x = CCAA, y = impacto)) +
  geom_col(aes(fill = impacto)) +  # Degradado para todas
  geom_col(
    data = subset(impacto_2020, CCAA == "España"),
    fill = "darkblue"
  ) +  # España resaltada
  coord_flip() +
  scale_fill_gradient2(
    low = "red", mid = "white", high = "blue", midpoint = 0
  ) +
  scale_y_continuous(
    breaks = seq(
      round(min(impacto_2020$impacto), 1),
      round(max(impacto_2020$impacto), 1),
      by = 0.5
    )
  ) +
  labs(
    title = "Impacto en el IMCV por CCAA (2020)",
    x = "CCAA",
    y = "Impacto (IMCV Real - Predicho)",
    fill = "Impacto"
  ) +
  theme_minimal(base_size = 15)

# Mostrar
print(barras_2020)


ggsave("resultados_report/barras_impacto_2020_correcto_v2.png", barras_2020, width = 8, height = 6)

# Obtener orden desde 2020 para poder hacer la comparación
orden_2020 <- impacto_ccaa %>%
  mutate(CCAA = ifelse(CCAA == "Total", "España", CCAA)) %>%
  filter(Anyo == 2020) %>%
  arrange(impacto) %>%
  pull(CCAA)

# Preparar datos para 2022
datos_2022 <- impacto_ccaa %>%
  mutate(CCAA = ifelse(CCAA == "Total", "España", CCAA)) %>%
  filter(Anyo == 2022) %>%
  mutate(CCAA = factor(CCAA, levels = orden_2020))

# Crear gráfico con España con otro color
barras_2022 <- ggplot(datos_2022, aes(x = CCAA, y = impacto)) +
  geom_col(aes(fill = impacto)) +  
  geom_col(
    data = subset(datos_2022, CCAA == "España"),
    fill = "darkblue"
  ) +  # España en azul oscuro
  coord_flip() +
  scale_fill_gradient2(
    low = "red", mid = "white", high = "blue", midpoint = 0
  ) +
  labs(
    title = "Impacto en el IMCV por CCAA (2022)",
    x = "CCAA",
    y = "Impacto (IMCV Real - Predicho)",
    fill = "Impacto"
  ) +
  scale_y_continuous(breaks = seq(round(min(impacto_ccaa$impacto),1), round(max(impacto_ccaa$impacto),1), by = 0.5)) +
  theme_minimal(base_size = 15)


print(barras_2022)

# Guardar
ggsave("resultados_report/barras_impacto_2022_correcto_v2.png", barras_2022, width = 8, height = 6)



# Ver las regiones más afectadas

excluir_ccaa <- c("Ceuta", "Melilla", "Total")

impacto_filtrado <- impacto_ccaa %>%
  filter(Anyo %in% c(2020, 2022),  !CCAA %in% excluir_ccaa)

#  2020 
impacto_2020 <- impacto_filtrado %>%
  filter(Anyo == 2020) %>%
  arrange(impacto)

top5_mas_afectadas_2020 <- head(impacto_2020, 5)
top5_menos_afectadas_2020 <- tail(impacto_2020, 5)

# mas afectadas
print(top5_mas_afectadas_2020)

# menos afectadas
print(top5_menos_afectadas_2020)


# 2022
impacto_2022 <- impacto_filtrado %>%
  filter(Anyo == 2022) %>%
  arrange(impacto)

top5_mas_afectadas_2022 <- head(impacto_2022, 5)
top5_menos_afectadas_2022 <- tail(impacto_2022, 5)

# mas afectadas
print(top5_mas_afectadas_2022)

# menos afectadas
print(top5_menos_afectadas_2022)



# Preparar tabla combinada
tabla_ccaa <- IMCV_reales %>%
  rename(IMCV_real = IMCV) %>%
  left_join(IMCV_predichos %>% rename(IMCV_predicho = IMCV),
            by = c("Anyo", "CCAA"))

# Función para crear gráfico individual
graficar_serie <- function(df, region) {
  df %>%
    filter(CCAA == region, Anyo >= 2014) %>%
    ggplot(aes(x = Anyo)) +
    geom_line(aes(y = IMCV_predicho, color = "Predicho"), size = 1.1) +
    geom_line(aes(y = IMCV_real, color = "Real"), size = 1.1) +
    scale_color_manual(values = c("Real" = "black", "Predicho" = "red")) +
    labs(title = region, x = "Años", y = "IMCV", color = "Serie") +
    scale_x_continuous(breaks = seq(2008, 2023, 2)) +
    theme_gray(base_size = 15, base_family = "Times New Roman")
  
}

# Crear gráficos mas afectadas
g1 <- graficar_serie(tabla_ccaa, "Canarias")
g2 <- graficar_serie(tabla_ccaa, "Castilla y León")
g3 <- graficar_serie(tabla_ccaa, "Catalunya")
g4 <- graficar_serie(tabla_ccaa, "Aragón")

# Guardar imágenes
g1 + g2 + plot_layout(ncol = 1)
ggsave("resultados_report/IMCV_mas_afectadas_parte1_v2.png", width = 10, height = 8)

(g3 + g4) + plot_layout(ncol = 1)
ggsave("resultados_report/IMCV_mas_afectadas_parte2_v2.png", width = 10, height = 8)



# Crear gráficos menos afectadas
g5 <- graficar_serie(tabla_ccaa, "Illes Balears")
g6 <- graficar_serie(tabla_ccaa, "País Vasco")
g7 <- graficar_serie(tabla_ccaa, "Andalucía")
g8 <- graficar_serie(tabla_ccaa, "Castilla-La Mancha")

# Guardar imágenes combinadas, dos por imagen
g5 + g6 + plot_layout(ncol = 1)
ggsave("resultados_report/IMCV_menos_afectadas_parte1_v2.png", width = 10, height = 8)

(g7 + g8) + plot_layout(ncol = 1)
ggsave("resultados_report/IMCV_menos_afectadas_parte2_v2.png", width = 10, height = 8)




### IMPACTO POR DIMENSIONES ###

impacto_dimension <- IMCV_reales_dim_nacional %>%
  rename(IMCV_real = IMCV) %>%
  left_join(IMCV_predichos_dim_nacional %>% rename(IMCV_predicho = IMCV),
            by = c("Anyo", "Dimension")) %>%
  mutate(Impacto = IMCV_real - IMCV_predicho) %>%
  left_join(dimensiones_nombres, by = "Dimension") %>%
  select(Anyo, Dimensión = dimension_limpia, IMCV_real, IMCV_predicho, Impacto)



lista_dimensiones <- impacto_dimension %>%
  group_split(Dimensión) %>%
  setNames(unique(impacto_dimension$Dimensión))

# 2. Guardar en Excel
write_xlsx(lista_dimensiones, "resultados_report/impacto_dimension_hojas_separadas.xlsx")


impacto_dimension_ancho <- impacto_dimension %>%
  filter(Anyo >= 2020) %>%
  select(Dimensión, Anyo, Impacto) %>%
  pivot_wider(names_from = Anyo, values_from = Impacto)

# Guardar tabla
write_xlsx(impacto_dimension, "resultados_report/impacto_imcv_dimensiones.xlsx")
saveRDS(impacto_dimension, "resultados_report/impacto_imcv_dimensiones.rds")
write_xlsx(impacto_dimension_ancho, "resultados_report/impacto_imcv_dimensiones_wide.xlsx")

### GRAFICOS DE LÍNEAS POR DIMENSIÓN ###

# Lista de dimensiones
dimensiones <- unique(impacto_dimension$Dimensión)

# Crear y guardar gráficos por dimensión
for (dim in dimensiones) {
  grafico_linea <- impacto_dimension %>%
    filter(Dimensión == dim, Anyo >= 2014) %>%
    ggplot(aes(x = Anyo)) +
    geom_line(aes(y = IMCV_predicho, color = "Predicho"), size = 1.1) +
    geom_line(aes(y = IMCV_real, color = "Real"), size = 1.1) +
    scale_color_manual(values = c("Real" = "black", "Predicho" = "red")) +
    labs(
      title = paste("Dimensión:", dim),
      x = "Años",
      y = "IMCV",
      color = "Serie"
    ) +
    scale_x_continuous(breaks = seq(2008, 2023, 2)) +
    theme_gray(base_size = 15, base_family = "Times New Roman")
  
  print(grafico_linea)
  
  ggsave(
    filename = paste0("resultados_report/IMCV_dimension_estrecha_", dim, ".png"),
    plot = grafico_linea, width = 8, height = 4
  )
}



### GRAFICOS BARRAS DE BARRAS POR AÑO (2020 y 2022) ###


# Obtener el orden DESC desde 2020
orden_dimensiones <- impacto_dimension %>%
  filter(Anyo == 2020) %>%
  arrange(Impacto) %>%
  pull(Dimensión)


graficar_barras_dimension <- function(anio, orden_dim, eje) {
  datos_anio <- impacto_dimension %>%
    filter(Anyo == anio) %>%
    mutate(Dimensión = factor(Dimensión, levels = orden_dim))  # Orden fijo
  
  ggplot(datos_anio, aes(x = Dimensión, y = Impacto, fill = Impacto)) +
    geom_col() +
    coord_flip() +
    scale_fill_gradient2(low = "red", mid = "white", high = "blue", midpoint = 0) +
    scale_y_continuous(breaks = seq(
      round(min(datos_anio$Impacto), 1),
      round(max(datos_anio$Impacto), 1), by = eje
    )) +
    labs(
      title = paste("Impacto del IMCV por Dimensión en", anio),
      x = "Dimensión",
      y = "Impacto (IMCV Real - Predicho)",
      fill = "Impacto"
    ) +
    theme_minimal(base_size = 15)
}

# Crear y guardar gráficos
barras_2020_dim <- graficar_barras_dimension(2020, orden_dimensiones, 0.5)
ggsave("resultados_report/barras_impacto_dim_2020_eje.png", barras_2020_dim, width = 10, height = 6)
barras_2022_dim <- graficar_barras_dimension(2022, orden_dimensiones, 1)
ggsave("resultados_report/barras_impacto_dim_2022_eje.png", barras_2022_dim, width = 10, height = 6)



### Tabla cruzada CCAA y dimension
ccaa_nombres

# Aplicar corrección después del cálculo del impacto
impacto_df <- IMCV_reales_dim %>%
  rename(IMCV_real  = IMCV) %>%
  left_join(
    IMCV_predichos_dim %>% rename(IMCV_predicho  = IMCV),
    by = c("Anyo", "CCAA", "Dimension")
  ) %>%
  mutate(Impacto = IMCV_real - IMCV_predicho) %>%
  filter(Anyo >= 2020) %>%
  left_join(ccaa_nombres, by = c("CCAA" = "ccaa"))

# Renombrar dimensiones a D1-D9
dimensiones_ordenadas <- impacto_df %>%
  distinct(Dimension) %>%
  arrange(Dimension) %>%
  mutate(D_short = paste0("D", row_number()))

impacto_df <- impacto_df %>%
  left_join(dimensiones_ordenadas, by = "Dimension")

# Crear tabla wide final
impacto_wide <- impacto_df %>%
  select(Anyo, CCAA = nombre_ccaa, D_short, Impacto) %>%
  pivot_wider(names_from = D_short, values_from = Impacto) %>%
  arrange(CCAA, Anyo)


write_xlsx(impacto_wide, "resultados_report/impacto_imcv_ccaa_dimensiones_wide.xlsx")
