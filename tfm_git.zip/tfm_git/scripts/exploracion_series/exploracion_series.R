# Cargar librerías necesarias
library(dplyr)
library(readxl)
library(openxlsx)

# Leer archivo con series
datos <- readRDS("datos/series_originales.rds")

# Leer archivo de codificación
codificacion_variables <- read_excel("datos/codificacion_variables.xlsx")

# Unir todos los datos en un solo df
df_unido <- lapply(datos, function(serie) {
  data.frame(
    variable = serie$variable,
    Valor = serie$data$valores
  )
}) %>% bind_rows()

# Calcular estadísticas básicas por variable
resumen_por_variable <- df_unido %>%
  group_by(variable) %>%
  summarise(
    n_obs = n(),
    n_NA = sum(is.na(Valor)),
    min = round(min(Valor, na.rm = TRUE), 2),
    max = round(max(Valor, na.rm = TRUE), 2),
    media = round(mean(Valor, na.rm = TRUE), 2),
    mediana = round(median(Valor, na.rm = TRUE), 2),
    sd = round(sd(Valor, na.rm = TRUE), 2),
    varianza = round(var(Valor, na.rm = TRUE), 2),
    coef_var = round(ifelse(mean(Valor, na.rm = TRUE) != 0, sd(Valor, na.rm = TRUE) / mean(Valor, na.rm = TRUE), NA), 2),
    .groups = "drop"
  )

# arreglar nombres
codificacion_variables <- codificacion_variables %>%
  rename(variable = Variable_nombre, variable_descripcion = Indice)

# unión
resumen_por_variable <- resumen_por_variable %>%
  left_join(codificacion_variables, by = "variable")

# Mostrar resultado
print("Estadísticas básicas por variable con descripciones unificadas:")
print(resumen_por_variable)






# Construir tabla con estadísticas por variable + ccaa
resumen_series_sa <- lapply(datos, function(serie) {
  valores <- serie$data$valores
  var <- var(valores, na.rm = TRUE)
  media <- mean(valores, na.rm = TRUE)
  sd_val <- sd(valores, na.rm = TRUE)
  
  data.frame(
    ccaa = serie$ccaa,
    variable = serie$variable,
    n_obs = length(valores),
    n_NA = sum(is.na(valores)),
    min = round(min(valores, na.rm = TRUE), 2),
    max = round(max(valores, na.rm = TRUE), 2),
    media = round(media, 2),
    mediana = round(median(valores, na.rm = TRUE), 2),
    sd = round(sd_val, 2),
    varianza = round(var, 2),
    coef_var = round(ifelse(!is.na(media) && media != 0, sd_val / media, NA), 2),
    es_plana = !is.na(var) && var < 1e-8
  )
}) %>% bind_rows()

# Unir con descripciones
resumen_series_sa <- resumen_series %>%
  left_join(codificacion_variables, by = "variable")

# Mostrar resultado
print("Estadísticas por serie (variable + comunidad):")
head(resumen_series_sa)



# Definir número esperado de observaciones (ajústalo si es otro)
longitud_esperada <- 16

# Construir tabla con resumen por serie
resumen_series <- lapply(datos, function(serie) {
  df <- serie$data
  n <- nrow(df)
  var <- var(df$valores, na.rm = TRUE)
  es_plano <- !is.na(var) && var < 1e-8
  longitud_incorrecta <- n != longitud_esperada
  
  data.frame(
    ccaa = serie$ccaa,
    variable = serie$variable,
    n_observaciones = n,
    varianza = round(var, 2),
    es_plano = es_plano,
    longitud_incorrecta = longitud_incorrecta
  )
}) %>% bind_rows()



resumen_series <- resumen_series %>%
  left_join(codificacion_variables, by = "variable")

# Mostrar tabla resumen
print("✅ Tabla con estado de cada serie (con descripción limpia):")
print(resumen_series)

# Filtrar solo las filas planas
series_planas <- resumen_series %>%
  filter(es_plano == TRUE)

# contar cuántas comunidades son planas
variables_planas_con_conteo <- series_planas %>%
  group_by(variable, Dimension, Subdimension ,variable_descripcion) %>%
  summarise(
    comunidades_planas = n(),
    .groups = "drop"
  )

# tabla final
print("Variables planas y número de comunidades donde lo son:")
print(variables_planas_con_conteo)

mydata <- write.xlsx(variables_planas_con_conteo,".xlsx")
saveWorkbook(mydata, file = "tablas_report/variables_planas_con_conteo.xlsx", overwrite = TRUE)




# Crear resumen con una fila por ccaa + variable
resumen_series <- lapply(datos, function(serie) {
  df <- serie$data
  varianza <- var(df$valores, na.rm = TRUE)
  es_plano <- !is.na(varianza) && varianza < 1e-5
  tiene_na <- any(is.na(df$valores))
  
  data.frame(
    variable = serie$variable,
    variable_descripcion = serie$data$Variable_descripcion,
    ccaa = serie$ccaa,
    es_plano = es_plano,
    tiene_na = tiene_na
  )
}) %>% bind_rows()

# Eliminar duplicados 
resumen_series <- resumen_series %>%
  distinct(variable, variable_descripcion, ccaa, .keep_all = TRUE)

# Agrupar por variable
resumen_por_variable <- resumen_series %>%
  group_by(variable, variable_descripcion) %>%
  summarise(
    comunidades_planas = sum(es_plano),
    comunidades_con_NA = sum(tiene_na),
    total_comunidades = n(),
    .groups = "drop"
  )

# Mostrar resultado
print("✅ Tabla resumen por variable (sin duplicados):")
print(resumen_por_variable)
print(unique(ccaa))

