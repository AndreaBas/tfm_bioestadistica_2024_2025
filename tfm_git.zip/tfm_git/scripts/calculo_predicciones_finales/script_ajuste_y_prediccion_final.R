library(forecast)
library(dplyr)
library(stringr)
library(bayesforecast)
library(readr)
library(writexl)
library(readxl)

# Cargar datos
series <- readRDS("datos/series_originales.rds")
indice_modelos <- read_excel("resultados_comparacion/analisis_modelos_variables_summary.xlsx", sheet = 3)

# Crear carpetas si no existen
dir.create("modelos_finales_ajustados", showWarnings = FALSE)
dir.create("series_prediccion", showWarnings = FALSE)

# Lista para guardar nuevas series
nuevas_series <- list()

# Función para generar nombre de archivo
nombre_modelo <- function(metodo, ccaa, variable) {
  paste0("modelos_finales_ajustados/", tolower(metodo), "_",
         str_replace_all(ccaa, " ", "_"), "_",
         str_replace_all(variable, " ", "_"), ".rds")
}

# Función que procesa cada serie individualmente
procesar_serie <- function(serie) {
  ccaa <- serie$ccaa
  variable <- serie$variable
  print(paste0("🔎 Procesando serie: ", ccaa, " - ", variable))
  
  metodo <- indice_modelos %>%
    filter(Variable == variable) %>%
    pull(Modelo_asignado) %>%
    unique() %>%
    first()
  
  if (is.null(metodo) || is.na(metodo)) {
    print(paste0("No hay método asignado para la variable: ", variable))
    return(NULL)
  }
  
  print(paste0("🔧 Método seleccionado: ", metodo))
  
  df <- serie$data
  df_train <- df %>% filter(Anyo <= 2019)
  
  if (nrow(df_train) < 2) {
    print("Pocos datos para entrenar el modelo. Saltando...")
    return(NULL)
  }
  
  print("📊 Transformando a serie temporal...")
  ts_train <- ts(df_train$valores, start = min(df_train$Anyo), frequency = 1)
  modelo <- NULL
  pred <- rep(NA, 4)
  
  print("⚙️ Ajustando modelo...")
  
  tryCatch({
    if (metodo == "NAIVE") {
      print("⚙️ Usando predicción manual para NAIVE...")
      # No usamos forecast(); solo repetimos el último valor
      ultimo_valor <- tail(ts_train, 1)
      modelo <- list(method = "manual_naive", ultimo_valor = ultimo_valor)
      pred <- rep(ultimo_valor, 4)
      
    } else if (metodo == "ETS") {
      modelo <- ets(ts_train)
      pred <- forecast(modelo, h = 4)$mean
      
    } else if (metodo == "ARIMA") {
      modelo <- auto.arima(ts_train)
      pred <- forecast(modelo, h = 4)$mean
      
    } else if (metodo == "NNETAR") {
      modelo <- nnetar(ts_train, repeats = 20)
      pred <- forecast(modelo, h = 4)$mean
      
    } else if (metodo == "BAYES") {
      modelo <- auto.sarima(ts_train, seasonal = FALSE,
                            chains = 4, iter = 5000, warmup = 1000, adapt.delta = 0.995)
      pred <- forecast(modelo, h = 4)$mean
      
    } else {
      stop("Método no reconocido: ", metodo)
    }
    
    print("Modelo ajustado correctamente.")
    print("Predicciones obtenidas:")
    print(round(pred, 2))
    
    print("Guardando modelo...")
    saveRDS(modelo, nombre_modelo(metodo, ccaa, variable))
    
    anyos_pred <- (max(df_train$Anyo) + 1):(max(df_train$Anyo) + 4)
    df_pred <- data.frame(Anyo = anyos_pred, valores = as.numeric(pred))
    
    nueva_serie <- bind_rows(
      df_train %>% select(Anyo, valores),
      df_pred
    )
    
    print("Serie predicciones creada con éxito.")
    return(list(ccaa = ccaa, variable = variable, data = nueva_serie))
    
  }, error = function(e) {
    print(paste0("Error al procesar ", ccaa, "-", variable, ": ", e$message))
    return(NULL)
  })
}

# Ejecutar una serie para test
resultado_prueba <- procesar_serie(series[[11]])

# Ejecutar para todas las series
print("Iniciando procesamiento...")
for (i in seq_along(series)) {
  print(paste0("Serie ", i, " de ", length(series)))
  resultado <- procesar_serie(series[[i]])
  if (!is.null(resultado)) {
    nuevas_series[[length(nuevas_series) + 1]] <- resultado
  }
}

saveRDS(nuevas_series, "series_prediccion/nuevas_series_prediccion.rds")

print("Proceso completado")




### Correcciones

series_completas <- readRDS("series_prediccion/nuevas_series_predicion_corregida.rds")

# Variables a recalcular
variables_recalcular <- c("V.5.2.3", "V.5.2.4")

# Filtrar
series_filtradas <- series[sapply(series, function(s) s$variable %in% variables_recalcular)]

# Procesar
print(paste0("Iniciando procesamiento de ", length(series_filtradas), " series seleccionadas..."))

for (i in seq_along(series_filtradas)) {
  print(paste0("Serie ", i, " de ", length(series_filtradas)))
  resultado <- procesar_serie(series_filtradas[[i]])
  if (!is.null(resultado)) {
    nuevas_series[[length(nuevas_series) + 1]] <- resultado
  }
}


# Actualizar los datos 

library(purrr)

variables_actualizar <- c("V.5.2.3", "V.5.2.4")

series_actualizadas <- series_completas %>%
  discard(~ .$variable %in% variables_actualizar)

series_combinadas <- c(series_actualizadas, nuevas_series)


saveRDS(series_combinadas, "series_prediccion/nuevas_series_prediccion_corregidas_v2.rds")

