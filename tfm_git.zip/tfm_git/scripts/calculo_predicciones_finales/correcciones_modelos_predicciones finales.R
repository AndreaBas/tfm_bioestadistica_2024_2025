library(forecast)
library(dplyr)
library(readxl)
library(stringr)
library(bayesforecast)
library(posterior)
library(readr)
library(writexl)


# cargar datos
series <- readRDS("datos/series_originales.rds")
indice_modelos <- read_excel("resultados_comparacion/analisis_modelos_variables_summary.xlsx", sheet = 3)

# Crear carpeta si no existe
dir.create("modelos_finales_ajustados_bayes_recheck", showWarnings = FALSE)

# Inicializar tabla de errores
log_errores <- data.frame(
  CCAA = character(),
  Variable = character(),
  Tipo = character(),
  Mensaje = character(),
  stringsAsFactors = FALSE
)

# Función auxiliar para guardar errores
registrar_error <- function(ccaa, variable, tipo, mensaje) {
  log_errores <<- rbind(log_errores, data.frame(
    CCAA = ccaa,
    Variable = variable,
    Tipo = tipo,
    Mensaje = mensaje
  ))
}

# Función para generar nombre de archivo
nombre_modelo <- function(ccaa, variable) {
  paste0("modelos_finales_ajustados_bayes_recheck/bayes_",
         str_replace_all(ccaa, " ", "_"), "_",
         str_replace_all(variable, " ", "_"), ".rds")
}

# Filtrar variables que usan BAYES
variables_bayes <- indice_modelos %>%
  filter(Modelo_asignado == "BAYES") %>%
  pull(Variable) %>%
  unique()

# Iterar solo por series BAYES
for (serie in series) {
  ccaa <- serie$ccaa
  variable <- serie$variable
  if (!(variable %in% variables_bayes)) next
  
  df <- serie$data
  df_train <- df %>% filter(Anyo <= 2019)
  
  if (nrow(df_train) < 8 || sd(df_train$valores, na.rm = TRUE) == 0) {
    registrar_error(ccaa, variable, "warning", "Serie insuficiente o sin variabilidad")
    next
  }
  
  ts_train <- ts(df_train$valores, start = min(df_train$Anyo), frequency = 1)
  
  warning_mensaje <- NULL
  error_mensaje <- NULL
  
  modelo <- withCallingHandlers(
    tryCatch({
      auto.sarima(ts_train, seasonal = FALSE,
                  chains = 4, iter = 5000, warmup = 1000, adapt.delta = 0.995)
    }, error = function(e) {
      error_mensaje <<- e$message
      return(NULL)
    }),
    warning = function(w) {
      warning_mensaje <<- conditionMessage(w)
      invokeRestart("muffleWarning")
    }
  )
  
  if (!is.null(error_mensaje)) {
    registrar_error(ccaa, variable, "error", error_mensaje)
    next
  }
  
  if (!is.null(warning_mensaje)) {
    registrar_error(ccaa, variable, "warning", warning_mensaje)
  }
  
  # Guardar modelo
  saveRDS(modelo, nombre_modelo(ccaa, variable))
  cat("✅ Modelo BAYES ajustado para:", ccaa, "-", variable, "\n")
}

# Guardar log de errores
write.csv(log_errores, "resultados_comparacion/errores_modelos_bayes.csv", row.names = FALSE)
cat("📄 Registro de errores guardado en 'errores_modelos_bayes.csv'\n")



# Ruta donde están guardados los modelos BAYES
carpeta_modelos <- "modelos_finales_ajustados"
archivos <- list.files(carpeta_modelos, pattern = "^bayes_.*\\.rds$", full.names = TRUE)

# Inicializar tabla para guardar diagnósticos
diagnosticos <- data.frame(
  CCAA = character(),
  Variable = character(),
  Rhat_max = numeric(),
  ESS_bulk_min = numeric(),
  ESS_tail_min = numeric(),
  Estado = character(),
  stringsAsFactors = FALSE
)

# Recorrer cada modelo guardado
for (archivo in archivos) {
  nombre <- basename(archivo)
  
  # Extraer CCAA y Variable del nombre del archivo
  partes <- str_match(nombre, "^bayes_(.*)_(.*)\\.rds$")
  ccaa <- str_replace_all(partes[2], "_", " ")
  variable <- str_replace_all(partes[3], "_", " ")
  
  # Leer modelo
  modelo <- readRDS(archivo)
  
  # Intentar extraer resumen de MCMC
  resumen <- tryCatch({
    posterior::summarise_draws(modelo$stanfit)
  }, error = function(e) NULL)
  
  if (is.null(resumen)) {
    diagnosticos <- rbind(diagnosticos, data.frame(
      CCAA = ccaa,
      Variable = variable,
      Rhat_max = NA,
      ESS_bulk_min = NA,
      ESS_tail_min = NA,
      Estado = "Error en resumen"
    ))
    next
  }
  
  rhat <- max(resumen$rhat, na.rm = TRUE)
  ess_bulk <- min(resumen$ess_bulk, na.rm = TRUE)
  ess_tail <- min(resumen$ess_tail, na.rm = TRUE)
  
  estado <- if (is.finite(rhat) && rhat <= 1.1 && ess_bulk > 400 && ess_tail > 400) {
    "OK"
  } else {
    "Problema"
  }
  
  diagnosticos <- rbind(diagnosticos, data.frame(
    CCAA = ccaa,
    Variable = variable,
    Rhat_max = round(rhat, 3),
    ESS_bulk_min = round(ess_bulk, 1),
    ESS_tail_min = round(ess_tail, 1),
    Estado = estado
  ))
  
  cat("✅ Procesado:", ccaa, "-", variable, "->", estado, "\n")
}

# Guardar resultados
write_xlsx(diagnosticos, "resultados_metricas/diagnostico_modelos_bayesianos_1.xlsx")
saveRDS(diagnosticos, "resultados_metricas/diagnostico_modelos_bayesianos_1.rds")

cat("📄 Diagnóstico completado. Resultados guardados en 'resultados_metricas/'.\n")



### Correcciones adicionales

# Cargar datos
series <- readRDS("datos/series_originales.rds")
predicciones <- readRDS("series_prediccion/nuevas_series_prediccion.rds")

# Filtrar la serie concreta
serie_objetivo <- Filter(function(s) s$ccaa == "CastillaLaMancha" & s$variable == "V.9.2.1", series)[[1]]
df <- serie_objetivo$data
df_train <- df %>% filter(Anyo <= 2019)

# Crear serie temporal
ts_train <- ts(df_train$valores, start = min(df_train$Anyo), frequency = 1)

# Entrenar con naive()
modelo_naive <- naive(ts_train)

# Guardar modelo
modelo_path <- "modelos_finales_ajustados/naive_CastillaLaMancha_V.9.2.1.rds"
saveRDS(modelo_naive, modelo_path)

# Crear predicciones manualmente
ultimo_valor <- tail(ts_train, 1)
pred <- rep(ultimo_valor, 4)

# Crear nueva serie extendida
anyos_pred <- 2020:2023
df_pred <- data.frame(
  Anyo = anyos_pred,
  valores = pred
)
nueva_serie <- bind_rows(
  df_train %>% select(Anyo, valores),
  df_pred
)

# Reemplazar en la lista
for (i in seq_along(predicciones)) {
  if (predicciones[[i]]$ccaa == "CastillaLaMancha" && predicciones[[i]]$variable == "V.9.2.1") {
    predicciones[[i]]$data <- nueva_serie
    break
  }
}

# Guardar lista actualizada
saveRDS(predicciones, "series_prediccion/nuevas_series_predicion_corregida.rds")

print("Reajuste NAIVE completado y predicciones corregidas para CastillaLaMancha - V.9.2.1\n")

